# Minecraft-Clone
 
Recreating Minecraft using GDScript for some reason despite using C++ being an infinitely better choice.
 
<img src="https://github.com/NicholasConnors/Minecraft-Clone/blob/main/pic.PNG?raw=True">
